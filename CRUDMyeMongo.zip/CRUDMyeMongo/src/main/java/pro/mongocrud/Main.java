package pro.mongocrud;

import pro.conectarbanco.conectar;
import java.sql.Connection;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        conectaMongo conn = new conectaMongo();
        
      //  conn.insertValues("Muralha", "Goreilo", 1, false);
        
        conn.getValues();
        
        conectar obj = new conectar();
        Connection conexao = obj.connectionMySql();
        Scanner sc = new Scanner(System.in);
        System.out.println("Deseja buscar um aluno em especifico? 1 - Sim | 2 - Não");
        int a = sc.nextInt();
        String x = "";
        if(a == 1){
            System.out.println("Digite o codigo a buscar no banco:");
            int code = sc.nextInt();
            System.out.println("Cod: " + code);
            x = obj.dataBaseSelect(code);
        }
        else if(a == 2){
            obj.dataBaseSelectAO();
        }
        
        obj.closeConnectionMySql(conexao);
    }
}